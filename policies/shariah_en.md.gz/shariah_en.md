# Shariah Compliance

The Qurb app was created to help Muslims in worship and in following the Sunnah: reading the Quran, prayer times, duas, azkar and reminders of important days.

## Sources
The Arabic text of the Quran follows the commonly accepted recitation. Translations of the meanings and transliteration are for understanding and do not replace the original. We strive to use verified translations and reliable sources.

## Content
We strive to ensure the app's content does not contradict Shariah norms and contains nothing forbidden (haram).

## Prayer times
Prayer times and the qibla direction are calculated using recognized methods. This is an auxiliary tool; when in doubt, check with your local mosque.

## Disclaimer
The app does not replace knowledgeable scholars. For important or disputed religious matters, consult qualified scholars and muftis in your area.

## Feedback
If you notice an error in the text or translation, let us know and we will correct it as soon as possible: support@example.com

_Last updated: 2026-07-07_