# Shariah Compliance

The Qurb app was made to help Muslims in worship and in following the Sunnah: reading the Quran, prayer times, duas, azkar and reminders of important days.

## Sources
The Arabic text of the Quran follows the commonly accepted recitation. Translations of the meanings and transliteration are for understanding and do not replace the original. I strive to use verified translations and reliable sources.

## Content
I strive to ensure the app's content does not contradict Shariah norms and contains nothing forbidden (haram).

## Prayer times
Prayer times and the qibla direction are calculated using recognized methods. This is an auxiliary tool; when in doubt, check with your local mosque.

## Disclaimer
The app does not replace knowledgeable scholars. For important or disputed religious matters, consult knowledgeable people or knowledgeable scholars.

## Feedback
If you notice an error in the text or translation, let me know and I will correct it as soon as possible: yi.mutawir@gmail.com

_Last updated: 2026-07-07_