# Şəriətə uyğunluq

Qurb tətbiqi müsəlmanlara ibadətdə və Sünnəyə əməl etməkdə kömək üçün hazırlanıb: Quran oxumaq, namaz vaxtları, dualar, əzkarlar və mühüm günlər barədə xatırlatma.

## Mənbələr
Quranın ərəb mətni ümumi qəbul olunmuş qiraətə əsasən verilir. Məna tərcümələri və transliterasiya anlamaq üçündür və orijinalı əvəz etmir. Yoxlanılmış tərcümələrdən və etibarlı mənbələrdən istifadə etməyə çalışıram.

## Məzmun
Tətbiqin məzmununun şəriət normalarına zidd olmaması və qadağan (haram) heç nə olmaması üçün çalışıram.

## Namaz vaxtları
Namaz vaxtları və qiblə istiqaməti tanınmış üsullarla hesablanır. Bu köməkçi vasitədir; şübhə etdikdə yerli məscidinizlə yoxlayın.

## Məsuliyyətdən imtina
Tətbiq bilikli alimləri əvəz etmir. Mühüm və mübahisəli dini məsələlərdə bilikli insanlara və ya bilikli alimlərə müraciət edin.

## Rəy
Mətndə və ya tərcümədə səhv görsəniz, bizə bildirin — onu mümkün qədər tez düzəldəcəyəm: support@example.com

_Son yenilənmə: 2026-07-07_