# Maxfiylik siyosati

Qurb ilovasi musulmonlarga kundalik ibodatda yordam beradi: Qurʼon oʻqish, namoz vaqtlari, duolar va azkorlar. Biz maxfiyligingizni hurmat qilamiz va imkon qadar kam maʼlumot toʻplaymiz.

## Qanday maʼlumotlar ishlatiladi
Ilova asosan qurilmangizda ishlaydi. Sozlamalar (til, mavzu, shahar, hisoblash usuli) mahalliy saqlanadi va bizga yuborilmaydi. Joylashuvga ruxsat bersangiz, u faqat namoz vaqtlari va qibla yoʻnalishini hisoblash uchun ishlatiladi va serverlarimizda saqlanmaydi.

## Kontentni yuklab olish
Qurʼon tarjimalari, transliteratsiya va bayram matnlari kerak boʻlganda ochiq ombordan (GitHub CDN) yuklab olinadi va oflayn ishlash uchun qurilmada saqlanadi. Bu jarayonda shaxsiy maʼlumotlar uzatilmaydi.

## Uchinchi tomon xizmatlari
Ilova Google Play xizmatlaridan (yetkazib berish, yangilanishlar) foydalanishi mumkin; ularning maʼlumotlarni qayta ishlashi Google siyosatiga boʻysunadi. Biz shaxsiy maʼlumotlaringizni sotmaymiz va uchinchi tomonlarga bermaymiz.

## Bildirishnomalar
Azon bildirishnomalari va namoz eslatmalari qurilmangizda mahalliy yaratiladi.

## Bolalar
Ilova bolalar maʼlumotlarini toʻplash uchun moʻljallanmagan va shaxsiy maʼlumot soʻramaydi.

## Huquqlaringiz
Ruxsatlarni (masalan, joylashuv) istalgan vaqtda qurilma sozlamalaridan qaytarib olishingiz va yuklab olingan maʼlumotlarni ilovada oʻchirishingiz mumkin.

## Oʻzgarishlar
Biz ushbu siyosatni yangilashimiz mumkin. Joriy versiya doimo ilovada mavjud.

## Aloqa
Maxfiylik savollari uchun: support@example.com

_Oxirgi yangilanish: 2026-07-07_