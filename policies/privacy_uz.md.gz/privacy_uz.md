# Maxfiylik siyosati

Qurb shaxsiy maʼlumotlaringizni yigʻmaydi, reklama koʻrsatmaydi va axborotni uchinchi tomonlarga bermaydi.

Ushbu siyosat Qurb ilovasi («ilova») axborot bilan qanday ishlashini tushuntiradi. Ilovadan foydalanish orqali siz quyidagi shartlarni qabul qilasiz.

## Biz qanday maʼlumotlarni yigʻmaymiz

Biz roʻyxatdan oʻtishni talab qilmaymiz va hisob yaratmaymiz. Ilova quyidagilarni yigʻmaydi va bizga yubormaydi:

• ism, elektron pochta manzili, telefon raqami;
• kontaktlar, suratlar, fayllar, taqvim;
• oʻqish tarixi, xatcho‘plar, eslatmalar va boshqa har qanday faoliyat;
• qurilmaning reklama identifikatorlari.

Ilovada tahlil vositalari, kuzatuvchilar va reklama SDK’lari yoʻq.

## Joylashuv

Ilova joylashuvga ruxsatni yagona maqsad uchun soʻraydi: namoz vaqtlari va qibla yoʻnalishini hisoblash. Ruxsat majburiy emas — shaharni qoʻlda ham kiritishingiz mumkin.

• Namoz vaqtlari astronomik formulalar asosida qurilmangizning oʻzida hisoblanadi. Buning uchun koordinatalaringiz hech qayerga yuborilmaydi.
• Qibla yoʻnalishi koordinatalar va kompas maʼlumotlari asosida qurilmada hisoblanadi.
• Shahringiz nomini koʻrsatish uchun ilova telefoningizning tizim geokoderiga (Google yoki Apple xizmati) murojaat qiladi. Shu payt koordinatalar operatsion tizim tomonidan oʻz ishlab chiquvchisining siyosatiga muvofiq qayta ishlanadi. Tarmoq boʻlmasa, shahar nomi ilovaga oʻrnatilgan shaharlar bazasidan oflayn tanlanadi.

Joylashuvingiz faqat qurilmangiz xotirasida saqlanadi. Uni saqlaydigan serverlarimiz yoʻq.

## Qurilmangizdagi maʼlumotlar

Xatcho‘plar, shaxsiy eslatmalar, sevimli duolar va azkorlar, takrorlash hisoblagichlari, tanlangan til, mavzu va shrift sozlamalari mahalliy saqlanadi. Ular telefondan chiqmaydi va ilova bilan birga oʻchiriladi. Bizda ularga kirish imkoni yoʻq va ularni tiklay olmaymiz.

## Ob-havo

Asosiy ekranda ob-havo yoki prognozni ochsangiz, ilova joriy holat va prognozni olish uchun tanlangan joy koordinatalarini ob-havo xizmatiga (WeatherAPI.com; u ishlamasa — Open-Meteo) yuboradi. Hech qanday identifikatorsiz, faqat koordinatalar va interfeys tili yuboriladi. Javob qurilmada keshlanadi.

## Tarmoq soʻrovlari va uchinchi tomon xizmatlari

Qurʼonning arabcha matni, duolar va namoz vaqtlari oflayn ishlaydi. Internet faqat qoʻshimcha materiallarni yuklab olish uchun kerak; shundan soʻng ular ham tarmoqsiz mavjud boʻladi. Bunday soʻrovlarda uchinchi tomon xizmati texnik jihatdan qurilmangiz IP-manzilini koʻradi — xuddi har qanday saytni ochgandagi kabi. Biz bu xizmatlarga siz haqingizda hech qanday maʼlumot bermaymiz.

• api.weatherapi.com, api.open-meteo.com — tanlangan joy koordinatalari bo‘yicha ob-havo va prognoz;
• api.quran.com, cdn.jsdelivr.net — Qurʼon maʼnolari tarjimalari va yordamchi maʼlumotlar;
• everyayah.com — Qurʼonning audio qiroati;
• hadeethenc.com — hadis manbasi koʻrsatilgan duo va azkor matnlari;
• images.unsplash.com — bezak uchun fon tasvirlari.

Bu xizmatlar mustaqil tashkilotlar tomonidan boshqariladi va oʻz maxfiylik siyosatlariga amal qiladi. Ilova oʻrnatish va yangilanishlar uchun Google Play xizmatlaridan ham foydalanishi mumkin.

## Bildirishnomalar

Azon, namoz vaqti eslatmalari va muhim sanalar yaqinlashgani haqidagi ogohlantirishlar qurilmada mahalliy yaratiladi. Biz serverdan yuboriladigan push-bildirishnomalardan foydalanmaymiz. Ularni ilova yoki tizim sozlamalaridan oʻchirish mumkin.

## Bolalar

Ilova har qanday yosh uchun mos va hech kimdan, jumladan bolalardan ham, shaxsiy maʼlumot yigʻmaydi.

## Sizning huquqlaringiz

Biz maʼlumotlaringizni saqlamaganimiz uchun soʻrov boʻyicha topshiradigan yoki oʻchiradigan narsamiz yoʻq. Ilovaning barcha maʼlumotlarini oʻchirish uchun uni qurilmadan olib tashlang yoki tizim sozlamalarida ilova maʼlumotlarini tozalang. Joylashuvga ruxsatni istalgan vaqtda telefon sozlamalaridan qaytarib olishingiz mumkin.

## Siyosatdagi oʻzgarishlar

Agar ilovaning ishlashi oʻzgarsa, biz ushbu sahifani va yuqoridagi kuchga kirish sanasini yangilaymiz. Jiddiy oʻzgarishlar ilovalar doʻkonidagi yangilanish tavsifida qayd etiladi.

## Biz bilan bogʻlanish

Maxfiylik boʻyicha savollar, izohlar va takliflarni quyidagi manzilga yuboring: yi.mutawir@gmail.com

Biz har bir xatga javob beramiz.

_Kuchga kirish sanasi: 2026-yil 10-iyul_
