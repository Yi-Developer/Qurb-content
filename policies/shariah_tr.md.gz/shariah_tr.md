# Şeriata Uygunluk

Qurb uygulaması, Müslümanlara ibadette ve Sünnete uymada yardımcı olmak için oluşturuldu: Kurʼan okuma, namaz vakitleri, dualar, ezkar ve önemli günlerin hatırlatılması.

## Kaynaklar
Kurʼan'ın Arapça metni yaygın kabul gören kıraate göre verilir. Meallerin çevirileri ve okunuş anlamak içindir ve aslın yerini tutmaz. Doğrulanmış çeviriler ve güvenilir kaynaklar kullanmaya özen gösteriyoruz.

## İçerik
Uygulama içeriğinin şeriat kurallarına aykırı olmamasına ve yasak (haram) hiçbir şey içermemesine özen gösteriyoruz.

## Namaz vakitleri
Namaz vakitleri ve kıble yönü tanınmış yöntemlerle hesaplanır. Bu yardımcı bir araçtır; şüphe durumunda yerel caminizle teyit edin.

## Sorumluluk reddi
Uygulama, ilim ehli âlimlerin yerini tutmaz. Önemli ve ihtilaflı dini meselelerde bölgenizdeki ehil âlim ve müftülere başvurun.

## Geri bildirim
Metinde veya çeviride bir hata fark ederseniz bize bildirin; en kısa sürede düzeltelim: support@example.com

_Son güncelleme: 2026-07-07_