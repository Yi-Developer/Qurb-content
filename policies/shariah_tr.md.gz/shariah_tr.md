# Şeriata Uygunluk

Qurb uygulaması, Müslümanlara ibadette ve Sünnete uymada yardımcı olmak için yapıldı: Kurʼan okuma, namaz vakitleri, dualar, ezkar ve önemli günlerin hatırlatılması.

## Kaynaklar
Kurʼan'ın Arapça metni yaygın kabul gören kıraate göre verilir. Meallerin çevirileri ve okunuş anlamak içindir ve aslın yerini tutmaz. Doğrulanmış çeviriler ve güvenilir kaynaklar kullanmaya özen gösteriyorum.

## İçerik
Uygulama içeriğinin şeriat kurallarına aykırı olmamasına ve yasak (haram) hiçbir şey içermemesine özen gösteriyorum.

## Namaz vakitleri
Namaz vakitleri ve kıble yönü tanınmış yöntemlerle hesaplanır. Bu yardımcı bir araçtır; şüphe durumunda yerel caminizle teyit edin.

## Sorumluluk reddi
Uygulama, ilim ehli âlimlerin yerini tutmaz. Önemli ve ihtilaflı dini meselelerde bilen kişilere veya ilim ehli âlimlere başvurun.

## Geri bildirim
Metinde veya çeviride bir hata fark ederseniz bana bildirin; en kısa sürede düzelteyim: yi.mutawir@gmail.com

_Son güncelleme: 2026-07-07_