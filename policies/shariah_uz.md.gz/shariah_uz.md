# Shariatga muvofiqlik

Qurb ilovasi musulmonlarga ibodatda va Sunnatga amal qilishda yordam berish uchun tayyorlangan: Qurʼon oʻqish, namoz vaqtlari, duolar, azkorlar va muhim kunlar haqida eslatma.

## Manbalar
Qurʼonning arab matni umumiy qabul qilingan qiroat boʻyicha keltiriladi. Maʼnolar tarjimasi va transliteratsiya tushunish uchun boʻlib, aslini almashtirmaydi. Tekshirilgan tarjimalar va ishonchli manbalardan foydalanishga harakat qilaman.

## Kontent
Ilova kontenti shariat meʼyorlariga zid boʻlmasligi va taqiqlangan (harom) narsa boʻlmasligi uchun harakat qilaman.

## Namoz vaqtlari
Namoz vaqtlari va qibla yoʻnalishi tan olingan usullar bilan hisoblanadi. Bu yordamchi vosita; shubha qilsangiz, mahalliy masjidingiz bilan tekshiring.

## Masʼuliyatdan voz kechish
Ilova bilimli olimlarni almashtirmaydi. Muhim va bahsli diniy masalalarda bilimli odamlarga yoki bilimli olimlarga murojaat qiling.

## Fikr-mulohaza
Matn yoki tarjimada xato koʻrsangiz, menga xabar bering — uni imkon qadar tez tuzataman: support@example.com

_Oxirgi yangilanish: 2026-07-07_