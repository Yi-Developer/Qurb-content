# Gizlilik Politikası

Qurb kişisel verilerinizi toplamaz, reklam göstermez ve bilgilerinizi üçüncü taraflarla paylaşmaz.

Bu politika, Qurb uygulamasının (“uygulama”) bilgileri nasıl işlediğini açıklar. Uygulamayı kullanarak aşağıdaki koşulları kabul etmiş olursunuz.

## Toplamadığımız veriler

Uygulama kayıt istemez ve hesap oluşturmaz. Şunları toplamaz ve bize göndermez:

• adınız, e-posta adresiniz veya telefon numaranız;
• kişiler, fotoğraflar, dosyalar, takvim;
• okuma geçmişi, yer imleri, notlar veya başka herhangi bir etkinlik;
• cihazın reklam kimlikleri.

Uygulamada analitik, izleyici ve reklam SDK’sı bulunmaz.

## Konum

Uygulama konum iznini tek bir amaçla ister: namaz vakitlerini ve kıble yönünü hesaplamak. İzin zorunlu değildir — şehrinizi elle de girebilirsiniz.

• Namaz vakitleri, astronomik formüllerle doğrudan cihazınızda hesaplanır. Bunun için koordinatlarınız hiçbir yere gönderilmez.
• Kıble yönü, koordinatlar ve pusula verileriyle cihazınızda hesaplanır.
• Şehrinizin adını göstermek için uygulama, telefonunuzun sistem coğrafi kodlayıcısını (Google veya Apple hizmeti) çağırır. Bu anda koordinatlarınız, işletim sistemi tarafından kendi sağlayıcısının politikasına göre işlenir. Ağ yokken şehir adı, uygulamanın içine gömülü şehir veritabanından çevrimdışı olarak bulunur.

Konumunuz yalnızca cihazınızın belleğinde tutulur. Saklanabileceği bir sunucumuz yoktur.

## Cihazınızdaki veriler

Yer imleri, kişisel notlar, favori dualar ve ezkâr, tekrar sayaçları, seçtiğiniz dil, tema ve yazı tipi ayarları cihazınızda yerel olarak saklanır. Telefonunuzdan çıkmaz ve uygulamayı kaldırdığınızda silinir. Bunlara erişemeyiz ve geri getiremeyiz.

## Hava durumu

Ana ekranda hava durumunu veya tahmini açarsanız, uygulama güncel koşulları ve tahmini almak için seçilen yerin koordinatlarını bir hava durumu servisine (WeatherAPI.com; erişilemezse Open-Meteo) gönderir. Hiçbir tanımlayıcı olmadan yalnızca koordinatlar ve arayüz dili iletilir. Yanıt cihazda önbelleğe alınır.

## Ağ istekleri ve üçüncü taraf hizmetleri

Kur’an’ın Arapça metni, dualar ve namaz vakitleri çevrimdışı çalışır. İnternet yalnızca ek içerikleri indirmek için gerekir; indirildikten sonra bunlar da çevrimdışı kullanılabilir. Böyle bir istek sırasında üçüncü taraf hizmet, herhangi bir web sitesini açtığınızdaki gibi cihazınızın IP adresini teknik olarak görür. Bu hizmetlere sizinle ilgili hiçbir bilgi göndermeyiz.

• api.weatherapi.com, api.open-meteo.com — seçilen yerin koordinatlarına göre hava durumu ve tahmin;
• api.quran.com, cdn.jsdelivr.net — Kur’an meallerinin çevirileri ve yardımcı veriler;
• everyayah.com — Kur’an sesli okuması;
• hadeethenc.com — hadis kaynağı belirtilen dua ve ezkâr metinleri;
• images.unsplash.com — arka plan görselleri.

Bu hizmetler bağımsız kuruluşlarca yürütülür ve kendi gizlilik politikalarına tabidir. Uygulama ayrıca kurulum ve güncellemeler için Google Play hizmetlerini kullanabilir.

## Bildirimler

Ezan, namaz vakti hatırlatmaları ve yaklaşan önemli günlere dair uyarılar cihazınızda yerel olarak oluşturulur. Sunucudan gönderilen push bildirimleri kullanmayız. Bunları uygulama veya sistem ayarlarından kapatabilirsiniz.

## Çocuklar

Uygulama her yaşa uygundur ve çocuklar dâhil hiç kimseden kişisel veri toplamaz.

## Haklarınız

Verilerinizi saklamadığımız için, talebiniz üzerine size verebileceğimiz ya da silebileceğimiz bir şey yoktur. Tüm uygulama verilerini silmek için uygulamayı kaldırın veya sistem ayarlarından verilerini temizleyin. Konum iznini istediğiniz zaman telefon ayarlarından geri alabilirsiniz.

## Politikadaki değişiklikler

Uygulamanın davranışı değişirse bu sayfayı ve yukarıdaki yürürlük tarihini güncelleriz. Önemli değişiklikler, uygulama mağazasındaki sürüm notlarında belirtilir.

## Bize ulaşın

Gizlilikle ilgili sorularınızı, düzeltmelerinizi ve önerilerinizi şu adrese gönderin: yi.mutawir@gmail.com

Her mesaja yanıt veriyoruz.

_Yürürlük tarihi: 10 Temmuz 2026_
