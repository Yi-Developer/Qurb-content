# Gizlilik Politikası

Qurb uygulaması Müslümanlara günlük ibadette yardımcı olur: Kurʼan okuma, namaz vakitleri, dualar ve ezkar. Gizliliğinize saygı duyuyor ve mümkün olduğunca az veri topluyoruz.

## Hangi veriler kullanılır
Uygulama esas olarak cihazınızda çalışır. Ayarlar (dil, tema, şehir, hesaplama yöntemi) yerel olarak saklanır ve bize gönderilmez. Konum izni verirseniz, yalnızca namaz vakitlerini ve kıble yönünü hesaplamak için kullanılır ve sunucularımızda saklanmaz.

## İçerik indirme
Kurʼan çevirileri, okunuş ve bayram metinleri gerektiğinde açık bir depodan (GitHub CDN) indirilir ve çevrimdışı kullanım için cihazınızda önbelleğe alınır. Bu sırada hiçbir kişisel veri aktarılmaz.

## Üçüncü taraf hizmetleri
Uygulama Google Play hizmetlerini (dağıtım, güncellemeler) kullanabilir; bunların veri işlemesi Google'ın politikasına tabidir. Kişisel verilerinizi satmıyor veya üçüncü taraflarla paylaşmıyoruz.

## Bildirimler
Ezan bildirimleri ve namaz hatırlatmaları cihazınızda yerel olarak oluşturulur.

## Çocuklar
Uygulama çocukların verilerini toplamak için tasarlanmamıştır ve kişisel bilgi istemez.

## Haklarınız
İzinleri (ör. konum) istediğiniz zaman cihaz ayarlarından geri alabilir ve indirilen verileri uygulama içinden silebilirsiniz.

## Değişiklikler
Bu politikayı güncelleyebiliriz. Güncel sürüm her zaman uygulamada mevcuttur.

## İletişim
Gizlilik soruları için: support@example.com

_Son güncelleme: 2026-07-07_