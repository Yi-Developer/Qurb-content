# Privacy Policy

The Qurb app helps Muslims in daily worship: reading the Quran, prayer times, duas and azkar. I respect your privacy and collect as little data as possible.

## What data we use
The app works mainly on your device. Settings (language, theme, city, calculation method) are stored locally and are not sent to me. If you grant location access, it is used only to calculate prayer times and the qibla direction and is not stored on my servers.

## Content downloads
Quran translations, transliteration and holiday strings are downloaded from a public storage (GitHub CDN) as needed and cached on your device for offline use. No personal data is transmitted in the process.

## Third-party services
The app may use Google Play services (delivery and updates); their data handling is governed by Google's policy. I do not sell or share your personal data with third parties.

## Notifications
Adhan notifications and prayer reminders are generated locally on your device.

## Children
The app is not intended to collect children's data and does not request personal information.

## Your rights
You can revoke permissions (e.g. location) in your device settings at any time and delete downloaded data within the app.

## Changes
I may update this policy. The current version is always available in the app.

## Contact
For privacy questions: yi.mutawir@gmail.com

_Last updated: 2026-07-07_