# Privacy Policy

Qurb does not collect your personal data, does not show ads, and does not share information with third parties.

This policy explains how the Qurb app (“the app”) handles information. By using the app, you agree to the terms below.

## What we do not collect

The app has no sign-up and no user accounts. It does not collect or send us:

• your name, email address, or phone number;
• contacts, photos, files, or calendar;
• reading history, bookmarks, notes, or any other activity;
• advertising identifiers.

The app contains no analytics, no trackers, and no advertising SDKs.

## Location

The app requests location access for one purpose: to calculate prayer times and the direction of the qibla. The permission is optional — you can enter your city manually instead.

• Prayer times are calculated on your device using astronomical formulas. Your coordinates are not sent anywhere for this.
• The qibla direction is calculated on your device from your coordinates and compass data.
• To display your city name, the app calls your phone’s system geocoder (a Google or Apple service). At that moment your coordinates are handled by the operating system under its own provider’s policy. With no network, the city name is matched against a database bundled inside the app, entirely offline.

Your location is kept only in your device’s memory. We operate no servers where it could be stored.

## Data on your device

Bookmarks, personal notes, favourite duas and adhkar, repetition counters, your chosen language, theme, and font settings are stored locally. They never leave your phone and are removed when you uninstall the app. We cannot access or restore them.

## Network requests and third-party services

The Arabic Qur’an, duas, and prayer times work offline. An internet connection is needed only to download additional material, which is then available offline as well. During such a request, the third-party service technically sees your device’s IP address, as it would when you open any website. We send these services no information about you.

• api.quran.com, cdn.jsdelivr.net — Qur’an translations and supporting data;
• everyayah.com — Qur’an audio recitation;
• hadeethenc.com — dua and adhkar texts with hadith sources;
• images.unsplash.com — background imagery.

These services are run by independent organisations and operate under their own privacy policies. The app may also use Google Play services for installation and updates.

## Notifications

The adhan, prayer-time reminders, and notices about upcoming Islamic dates are generated locally on your device. We do not use server-sent push notifications. You can turn them off in the app or in your system settings.

## Children

The app is suitable for all ages and collects no personal data from anyone, including children.

## Your rights

Because we hold none of your data, there is nothing for us to hand over or delete on request. To erase all app data, uninstall the app or clear its storage in your system settings. You may revoke location access at any time from your phone’s settings.

## Changes to this policy

If the app’s behaviour changes, we will update this page and the effective date above. Material changes will be noted in the release notes on the app store.

## Contact us

Send privacy questions, corrections, or suggestions to yi.mutawir@gmail.com

We reply to every message.

_Effective date: 10 July 2026_
