# Məxfilik siyasəti

Qurb tətbiqi müsəlmanlara gündəlik ibadətdə kömək edir: Quran oxumaq, namaz vaxtları, dualar və əzkarlar. Məxfiliyinizə hörmət edir və mümkün qədər az məlumat toplayıram.

## Hansı məlumatlardan istifadə olunur
Tətbiq əsasən cihazınızda işləyir. Ayarlar (dil, tema, şəhər, hesablama metodu) yerli olaraq saxlanılır və mənə göndərilmir. Məkana icazə versəniz, o yalnız namaz vaxtlarını və qiblə istiqamətini hesablamaq üçün istifadə olunur və serverlərimdə saxlanılmır.

## Məzmunun yüklənməsi
Quran tərcümələri, transliterasiya və bayram mətnləri lazım olduqda açıq anbardan (GitHub CDN) yüklənir və oflayn iş üçün cihazınızda saxlanılır. Bu zaman heç bir şəxsi məlumat ötürülmür.

## Üçüncü tərəf xidmətləri
Tətbiq Google Play xidmətlərindən (çatdırılma, yeniləmələr) istifadə edə bilər; onların məlumat emalı Google-un siyasətinə tabedir. Şəxsi məlumatlarınızı satmıram və üçüncü tərəflərlə paylaşmıram.

## Bildirişlər
Azan bildirişləri və namaz xatırlatmaları cihazınızda yerli olaraq yaradılır.

## Uşaqlar
Tətbiq uşaqların məlumatlarını toplamaq üçün nəzərdə tutulmayıb və şəxsi məlumat tələb etmir.

## Hüquqlarınız
İcazələri (məsələn, məkan) istənilən vaxt cihaz ayarlarından geri ala və yüklənmiş məlumatları tətbiqdə silə bilərsiniz.

## Dəyişikliklər
Bu siyasəti yeniləyə bilərəm. Cari versiya həmişə tətbiqdə mövcuddur.

## Əlaqə
Məxfilik sualları üçün: support@example.com

_Son yenilənmə: 2026-07-07_