# Məxfilik siyasəti

Qurb şəxsi məlumatlarınızı toplamır, reklam göstərmir və məlumatları üçüncü tərəflərə vermir.

Bu siyasət Qurb tətbiqinin («tətbiq») məlumatlarla necə davrandığını izah edir. Tətbiqdən istifadə etməklə aşağıdakı şərtləri qəbul edirsiniz.

## Hansı məlumatları toplamırıq

Qeydiyyat tələb etmirik və hesab yaratmırıq. Tətbiq aşağıdakıları toplamır və bizə göndərmir:

• ad, e-poçt ünvanı, telefon nömrəsi;
• kontaktlar, şəkillər, fayllar, təqvim;
• oxu tarixçəsi, əlfəcinlər, qeydlər və hər hansı digər fəaliyyət;
• cihazın reklam identifikatorları.

Tətbiqdə analitika, izləyicilər və reklam SDK-ları yoxdur.

## Məkan

Tətbiq məkan icazəsini yalnız bir məqsədlə istəyir: namaz vaxtlarını və qiblə istiqamətini hesablamaq. İcazə məcburi deyil — şəhəri əl ilə də daxil edə bilərsiniz.

• Namaz vaxtları astronomik düsturlarla birbaşa cihazınızda hesablanır. Bunun üçün koordinatlarınız heç yerə göndərilmir.
• Qiblə istiqaməti koordinatlar və kompas məlumatları əsasında cihazda hesablanır.
• Şəhərinizin adını göstərmək üçün tətbiq telefonunuzun sistem geokoderinə (Google və ya Apple xidməti) müraciət edir. Bu zaman koordinatlar əməliyyat sistemi tərəfindən öz tərtibatçısının siyasətinə uyğun emal olunur. Şəbəkə olmadıqda şəhər adı tətbiqə daxil edilmiş şəhər bazasından oflayn seçilir.

Məkanınız yalnız cihazınızın yaddaşında saxlanılır. Onu saxlaya biləcək serverlərimiz yoxdur.

## Cihazınızdakı məlumatlar

Əlfəcinlər, şəxsi qeydlər, seçilmiş dualar və əzkarlar, təkrar sayğacları, seçdiyiniz dil, tema və şrift ayarları cihazda yerli saxlanılır. Onlar telefonu tərk etmir və tətbiqlə birlikdə silinir. Bizim onlara girişimiz yoxdur və onları bərpa edə bilmərik.

## Hava

Əsas ekranda havanı və ya proqnozu açsanız, tətbiq cari şərait və proqnozu almaq üçün seçilmiş yerin koordinatlarını hava xidmətinə (WeatherAPI.com; əlçatan olmadıqda — Open-Meteo) göndərir. Heç bir identifikator olmadan yalnız koordinatlar və interfeys dili ötürülür. Cavab cihazda keşlənir.

## Şəbəkə sorğuları və üçüncü tərəf xidmətləri

Quranın ərəbcə mətni, dualar və namaz vaxtları oflayn işləyir. İnternet yalnız əlavə materialları yükləmək üçün lazımdır; yükləndikdən sonra onlar da şəbəkəsiz əlçatan olur. Belə sorğular zamanı üçüncü tərəf xidməti texniki olaraq cihazınızın IP ünvanını görür — istənilən sayta daxil olduğunuz kimi. Bu xidmətlərə sizin haqqınızda heç bir məlumat vermirik.

• api.weatherapi.com, api.open-meteo.com — seçilmiş yerin koordinatlarına görə hava və proqnoz;
• api.quran.com, cdn.jsdelivr.net — Quran mənalarının tərcümələri və köməkçi məlumatlar;
• everyayah.com — Quranın audio qiraəti;
• hadeethenc.com — hədis mənbəyi göstərilən dua və əzkar mətnləri;
• images.unsplash.com — dizayn üçün fon şəkilləri.

Bu xidmətlər müstəqil təşkilatlar tərəfindən idarə olunur və öz məxfilik siyasətlərinə tabedir. Tətbiq quraşdırma və yeniləmələr üçün Google Play xidmətlərindən də istifadə edə bilər.

## Bildirişlər

Azan, namaz vaxtı xatırlatmaları və mühüm günlərin yaxınlaşması barədə bildirişlər cihazda yerli yaradılır. Serverdən göndərilən push bildirişlərindən istifadə etmirik. Onları tətbiq və ya sistem ayarlarından söndürmək olar.

## Uşaqlar

Tətbiq bütün yaşlar üçün uyğundur və uşaqlar da daxil olmaqla heç kimdən şəxsi məlumat toplamır.

## Hüquqlarınız

Məlumatlarınızı saxlamadığımız üçün sorğunuza əsasən sizə verə və ya silə biləcəyimiz heç nə yoxdur. Bütün tətbiq məlumatlarını silmək üçün onu cihazdan çıxarın və ya sistem ayarlarında tətbiqin məlumatlarını təmizləyin. Məkan icazəsini istənilən vaxt telefon ayarlarından geri ala bilərsiniz.

## Siyasətdəki dəyişikliklər

Tətbiqin davranışı dəyişərsə, bu səhifəni və yuxarıdakı qüvvəyəminmə tarixini yeniləyəcəyik. Əhəmiyyətli dəyişikliklər tətbiq mağazasındakı yeniləmə qeydlərində göstəriləcək.

## Bizimlə əlaqə

Məxfiliklə bağlı sualları, iradları və təklifləri bu ünvana göndərin: yi.mutawir@gmail.com

Hər məktuba cavab veririk.

_Qüvvəyə minmə tarixi: 10 iyul 2026_
